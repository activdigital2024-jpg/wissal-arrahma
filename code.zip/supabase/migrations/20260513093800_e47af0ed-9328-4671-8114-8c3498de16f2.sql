-- Add teacher_id and parent_email to students
ALTER TABLE public.students
  ADD COLUMN IF NOT EXISTS teacher_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS parent_email text;

CREATE INDEX IF NOT EXISTS idx_students_teacher_id ON public.students(teacher_id);

-- Helper: is current user the teacher of student?
CREATE OR REPLACE FUNCTION public.is_teacher_of(_student_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.students
    WHERE id = _student_id AND teacher_id = auth.uid()
  )
$$;

-- Teacher RLS on students: view/update own
CREATE POLICY "teacher view own students" ON public.students
  FOR SELECT USING (has_role(auth.uid(), 'teacher') AND teacher_id = auth.uid());

CREATE POLICY "teacher update own students" ON public.students
  FOR UPDATE USING (has_role(auth.uid(), 'teacher') AND teacher_id = auth.uid())
  WITH CHECK (has_role(auth.uid(), 'teacher') AND teacher_id = auth.uid());

-- Teacher RLS on payments: view own students only (no insert/update)
CREATE POLICY "teacher view own students payments" ON public.payments
  FOR SELECT USING (has_role(auth.uid(), 'teacher') AND public.is_teacher_of(student_id));

-- Teacher RLS on evaluations: full CRUD (except delete) for own students
CREATE POLICY "teacher view own students evaluations" ON public.evaluations
  FOR SELECT USING (has_role(auth.uid(), 'teacher') AND public.is_teacher_of(student_id));

CREATE POLICY "teacher insert evaluations for own students" ON public.evaluations
  FOR INSERT WITH CHECK (has_role(auth.uid(), 'teacher') AND public.is_teacher_of(student_id));

CREATE POLICY "teacher update own students evaluations" ON public.evaluations
  FOR UPDATE USING (has_role(auth.uid(), 'teacher') AND public.is_teacher_of(student_id))
  WITH CHECK (has_role(auth.uid(), 'teacher') AND public.is_teacher_of(student_id));

-- Teacher access settings (read)
CREATE POLICY "teacher read settings" ON public.app_settings
  FOR SELECT TO authenticated USING (has_role(auth.uid(), 'teacher'));

-- Teacher can read profiles
CREATE POLICY "teacher view profiles" ON public.profiles
  FOR SELECT USING (has_role(auth.uid(), 'teacher'));

-- ATTENDANCE TABLE
CREATE TABLE IF NOT EXISTS public.attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL,
  attendance_date date NOT NULL DEFAULT CURRENT_DATE,
  status text NOT NULL CHECK (status IN ('present','absent','late','excused')),
  reason text,
  notes text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (student_id, attendance_date)
);

CREATE INDEX IF NOT EXISTS idx_attendance_student_date ON public.attendance(student_id, attendance_date DESC);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON public.attendance(attendance_date DESC);

ALTER TABLE public.attendance ENABLE ROW LEVEL SECURITY;

-- Admin full
CREATE POLICY "admins all attendance" ON public.attendance
  FOR ALL USING (has_role(auth.uid(), 'admin'))
  WITH CHECK (has_role(auth.uid(), 'admin'));

-- Secretary: view/insert/update (no delete)
CREATE POLICY "secretary view attendance" ON public.attendance
  FOR SELECT USING (has_role(auth.uid(), 'secretary'));
CREATE POLICY "secretary insert attendance" ON public.attendance
  FOR INSERT WITH CHECK (has_role(auth.uid(), 'secretary'));
CREATE POLICY "secretary update attendance" ON public.attendance
  FOR UPDATE USING (has_role(auth.uid(), 'secretary'))
  WITH CHECK (has_role(auth.uid(), 'secretary'));

-- Teacher: view/insert/update for own students
CREATE POLICY "teacher view own attendance" ON public.attendance
  FOR SELECT USING (has_role(auth.uid(), 'teacher') AND public.is_teacher_of(student_id));
CREATE POLICY "teacher insert own attendance" ON public.attendance
  FOR INSERT WITH CHECK (has_role(auth.uid(), 'teacher') AND public.is_teacher_of(student_id));
CREATE POLICY "teacher update own attendance" ON public.attendance
  FOR UPDATE USING (has_role(auth.uid(), 'teacher') AND public.is_teacher_of(student_id))
  WITH CHECK (has_role(auth.uid(), 'teacher') AND public.is_teacher_of(student_id));

-- updated_at trigger
CREATE TRIGGER trg_attendance_updated_at
  BEFORE UPDATE ON public.attendance
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
