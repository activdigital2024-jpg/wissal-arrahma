
CREATE TABLE public.evaluations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL,
  level smallint NOT NULL DEFAULT 1,
  month smallint NOT NULL,
  year integer NOT NULL,
  eval_date date NOT NULL DEFAULT CURRENT_DATE,
  child_age text,
  educator_name text,
  ratings jsonb NOT NULL DEFAULT '{}'::jsonb,
  general_notes text,
  recommendations text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.evaluations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins all evaluations" ON public.evaluations
  FOR ALL USING (has_role(auth.uid(),'admin'::app_role))
  WITH CHECK (has_role(auth.uid(),'admin'::app_role));

CREATE TRIGGER evaluations_updated_at BEFORE UPDATE ON public.evaluations
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE INDEX idx_evaluations_student ON public.evaluations(student_id, year, month);
