-- Teacher absences table
CREATE TABLE public.teacher_absences (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id UUID NOT NULL,
  absence_date DATE NOT NULL,
  end_date DATE,
  reason TEXT NOT NULL,
  justification TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.teacher_absences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins all teacher absences" ON public.teacher_absences
  FOR ALL USING (has_role(auth.uid(), 'admin')) WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "secretary view teacher absences" ON public.teacher_absences
  FOR SELECT USING (has_role(auth.uid(), 'secretary'));

CREATE POLICY "teacher view own absences" ON public.teacher_absences
  FOR SELECT USING (has_role(auth.uid(), 'teacher') AND teacher_id = auth.uid());

CREATE POLICY "teacher insert own absences" ON public.teacher_absences
  FOR INSERT WITH CHECK (has_role(auth.uid(), 'teacher') AND teacher_id = auth.uid());

CREATE POLICY "teacher update own pending absences" ON public.teacher_absences
  FOR UPDATE USING (has_role(auth.uid(), 'teacher') AND teacher_id = auth.uid() AND status = 'pending')
  WITH CHECK (has_role(auth.uid(), 'teacher') AND teacher_id = auth.uid());

CREATE TRIGGER set_teacher_absences_updated_at
  BEFORE UPDATE ON public.teacher_absences
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
