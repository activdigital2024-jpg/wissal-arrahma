-- 1. Add teacher role
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'teacher';
