-- Students: secretary can SELECT, INSERT, UPDATE
CREATE POLICY "secretary view students" ON public.students FOR SELECT USING (has_role(auth.uid(), 'secretary'));
CREATE POLICY "secretary insert students" ON public.students FOR INSERT WITH CHECK (has_role(auth.uid(), 'secretary'));
CREATE POLICY "secretary update students" ON public.students FOR UPDATE USING (has_role(auth.uid(), 'secretary')) WITH CHECK (has_role(auth.uid(), 'secretary'));

-- Payments: secretary can SELECT, INSERT, UPDATE
CREATE POLICY "secretary view payments" ON public.payments FOR SELECT USING (has_role(auth.uid(), 'secretary'));
CREATE POLICY "secretary insert payments" ON public.payments FOR INSERT WITH CHECK (has_role(auth.uid(), 'secretary'));
CREATE POLICY "secretary update payments" ON public.payments FOR UPDATE USING (has_role(auth.uid(), 'secretary')) WITH CHECK (has_role(auth.uid(), 'secretary'));

-- Evaluations: secretary can SELECT, INSERT, UPDATE
CREATE POLICY "secretary view evaluations" ON public.evaluations FOR SELECT USING (has_role(auth.uid(), 'secretary'));
CREATE POLICY "secretary insert evaluations" ON public.evaluations FOR INSERT WITH CHECK (has_role(auth.uid(), 'secretary'));
CREATE POLICY "secretary update evaluations" ON public.evaluations FOR UPDATE USING (has_role(auth.uid(), 'secretary')) WITH CHECK (has_role(auth.uid(), 'secretary'));

-- Settings: secretary can read
CREATE POLICY "secretary read settings" ON public.app_settings FOR SELECT TO authenticated USING (has_role(auth.uid(), 'secretary'));

-- Profiles: secretary can read profiles
CREATE POLICY "secretary view profiles" ON public.profiles FOR SELECT USING (has_role(auth.uid(), 'secretary'));
