import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  getTemplate,
  RATING_OPTIONS,
  MONTH_NAMES,
  type RatingValue,
} from "@/lib/evaluationTemplates";
import { toast } from "sonner";
import { useNavigate } from "@tanstack/react-router";

type Student = { id: string; full_name: string };

export type EvaluationFormValues = {
  student_id: string;
  level: number;
  month: number;
  year: number;
  eval_date: string;
  child_age: string;
  educator_name: string;
  ratings: Record<string, RatingValue>;
  general_notes: string;
  recommendations: string;
};

export function EvaluationForm({
  initial,
  evaluationId,
}: {
  initial?: Partial<EvaluationFormValues>;
  evaluationId?: string;
}) {
  const navigate = useNavigate();
  const [students, setStudents] = useState<Student[]>([]);
  const now = new Date();
  const [v, setV] = useState<EvaluationFormValues>({
    student_id: initial?.student_id || "",
    level: initial?.level || 1,
    month: initial?.month || now.getMonth() + 1,
    year: initial?.year || now.getFullYear(),
    eval_date: initial?.eval_date || now.toISOString().slice(0, 10),
    child_age: initial?.child_age || "",
    educator_name: initial?.educator_name || "",
    ratings: initial?.ratings || {},
    general_notes: initial?.general_notes || "",
    recommendations: initial?.recommendations || "",
  });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase
      .from("students")
      .select("id, full_name")
      .eq("status", "active")
      .order("full_name")
      .then(({ data }) => setStudents(data || []));
  }, []);

  const template = getTemplate(v.level);

  const setRating = (item: string, val: RatingValue) =>
    setV((s) => ({ ...s, ratings: { ...s.ratings, [item]: val } }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!v.student_id) return toast.error("اختر الطفل");
    setBusy(true);
    const { data: auth } = await supabase.auth.getUser();
    const payload = { ...v, created_by: auth.user?.id };
    const res = evaluationId
      ? await supabase.from("evaluations").update(payload).eq("id", evaluationId).select().single()
      : await supabase.from("evaluations").insert(payload).select().single();
    setBusy(false);
    if (res.error) return toast.error(res.error.message);
    toast.success("تم الحفظ");
    navigate({ to: "/admin/evaluations/$id", params: { id: res.data.id } });
  };

  return (
    <form onSubmit={submit} className="space-y-6">
      <div className="grid gap-4 rounded-2xl border bg-card p-6 sm:grid-cols-2 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <label className="mb-1 block text-sm font-medium">الطفل</label>
          <select
            required
            value={v.student_id}
            onChange={(e) => setV({ ...v, student_id: e.target.value })}
            className="input"
          >
            <option value="">— اختر —</option>
            {students.map((s) => (
              <option key={s.id} value={s.id}>
                {s.full_name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">المستوى</label>
          <select
            value={v.level}
            onChange={(e) => setV({ ...v, level: Number(e.target.value), ratings: {} })}
            className="input"
          >
            <option value={1}>المستوى 1 (الأطفال الصغار)</option>
            <option value={2}>المستوى 2 (الأطفال الأكبر)</option>
          </select>
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">الشهر</label>
          <select
            value={v.month}
            onChange={(e) => setV({ ...v, month: Number(e.target.value) })}
            className="input"
          >
            {MONTH_NAMES.map((m, i) => (
              <option key={i} value={i + 1}>
                {m}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">السنة</label>
          <input
            type="number"
            value={v.year}
            onChange={(e) => setV({ ...v, year: Number(e.target.value) })}
            className="input"
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">تاريخ التقييم</label>
          <input
            type="date"
            value={v.eval_date}
            onChange={(e) => setV({ ...v, eval_date: e.target.value })}
            className="input"
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">السن</label>
          <input
            value={v.child_age}
            onChange={(e) => setV({ ...v, child_age: e.target.value })}
            className="input"
          />
        </div>
        <div className="lg:col-span-2">
          <label className="mb-1 block text-sm font-medium">اسم المربية</label>
          <input
            value={v.educator_name}
            onChange={(e) => setV({ ...v, educator_name: e.target.value })}
            className="input"
          />
        </div>
      </div>

      {template.map((section) => (
        <div key={section.title} className="rounded-2xl border bg-card p-4 sm:p-6">
          <h3 className="mb-4 text-lg font-bold text-primary">{section.title}</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="p-2 text-right">العنصر</th>
                  {RATING_OPTIONS.map((o) => (
                    <th key={o.value} className="p-2 text-center font-medium">
                      {o.label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {section.items.map((item) => (
                  <tr key={item} className="border-b last:border-0">
                    <td className="p-2">{item}</td>
                    {RATING_OPTIONS.map((o) => (
                      <td key={o.value} className="p-2 text-center">
                        <input
                          type="radio"
                          name={item}
                          checked={v.ratings[item] === o.value}
                          onChange={() => setRating(item, o.value)}
                          className="h-4 w-4 cursor-pointer accent-primary"
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}

      <div className="rounded-2xl border bg-card p-6">
        <label className="mb-1 block text-sm font-medium">ملاحظات عامة حول أداء الطفل</label>
        <textarea
          rows={4}
          value={v.general_notes}
          onChange={(e) => setV({ ...v, general_notes: e.target.value })}
          className="input"
        />
      </div>
      <div className="rounded-2xl border bg-card p-6">
        <label className="mb-1 block text-sm font-medium">توصيات شهرية</label>
        <textarea
          rows={4}
          value={v.recommendations}
          onChange={(e) => setV({ ...v, recommendations: e.target.value })}
          className="input"
        />
      </div>

      <button
        disabled={busy}
        className="rounded-lg bg-primary px-6 py-2 font-medium text-primary-foreground disabled:opacity-50"
      >
        {busy ? "..." : "حفظ التقييم"}
      </button>
    </form>
  );
}
