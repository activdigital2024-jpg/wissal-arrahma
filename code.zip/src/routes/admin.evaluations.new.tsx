import { createFileRoute } from "@tanstack/react-router";
import { EvaluationForm } from "@/components/EvaluationForm";

export const Route = createFileRoute("/admin/evaluations/new")({
  component: NewEvaluation,
});

function NewEvaluation() {
  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold">تقييم شهري جديد</h1>
      <EvaluationForm />
    </div>
  );
}
