import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { MONTH_NAMES } from "@/lib/evaluationTemplates";
import { Plus, Eye, Trash2, Zap } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

export const Route = createFileRoute("/admin/evaluations")({
  component: EvaluationsPage,
});

type Row = {
  id: string;
  student_id: string;
  level: number;
  month: number;
  year: number;
  eval_date: string;
  educator_name: string | null;
  students?: { full_name: string; teacher_id: string | null } | null;
};

type StudentOpt = {
  id: string;
  full_name: string;
  teacher_id: string | null;
};

function EvaluationsPage() {
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [rows, setRows] = useState<Row[]>([]);
  const [teachers, setTeachers] = useState<Record<string, string>>({});
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState<number | "">("");

  // Quick-create dialog state
  const [open, setOpen] = useState(false);
  const [students, setStudents] = useState<StudentOpt[]>([]);
  const [qStudent, setQStudent] = useState("");
  const [qMonth, setQMonth] = useState(now.getMonth() + 1);
  const [qYear, setQYear] = useState(now.getFullYear());
  const [qLevel, setQLevel] = useState(1);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    let q = supabase
      .from("evaluations")
      .select(
        "id, student_id, level, month, year, eval_date, educator_name, students(full_name, teacher_id)",
      )
      .eq("year", year)
      .order("eval_date", { ascending: false });
    if (month !== "") q = q.eq("month", month);
    const { data, error } = await q;
    if (error) return toast.error(error.message);
    const list = (data || []) as unknown as Row[];
    setRows(list);

    const ids = Array.from(
      new Set(list.map((r) => r.students?.teacher_id).filter(Boolean) as string[]),
    );
    if (ids.length) {
      const { data: profs } = await supabase
        .from("profiles")
        .select("id, full_name")
        .in("id", ids);
      const map: Record<string, string> = {};
      (profs || []).forEach((p: any) => (map[p.id] = p.full_name || ""));
      setTeachers(map);
    } else {
      setTeachers({});
    }
  };

  const loadStudents = async () => {
    const { data } = await supabase
      .from("students")
      .select("id, full_name, teacher_id")
      .eq("status", "active")
      .order("full_name");
    const list = (data || []) as StudentOpt[];
    setStudents(list);
    const ids = Array.from(
      new Set(list.map((s) => s.teacher_id).filter(Boolean) as string[]),
    );
    if (ids.length) {
      const { data: profs } = await supabase
        .from("profiles")
        .select("id, full_name")
        .in("id", ids);
      const map: Record<string, string> = { ...teachers };
      (profs || []).forEach((p: any) => (map[p.id] = p.full_name || ""));
      setTeachers(map);
    }
  };

  useEffect(() => {
    load();
  }, [year, month]);

  useEffect(() => {
    if (open && students.length === 0) loadStudents();
  }, [open]);

  const remove = async (id: string) => {
    if (!confirm("حذف هذا التقييم؟")) return;
    const { error } = await supabase.from("evaluations").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("تم الحذف");
    load();
  };

  const quickCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!qStudent) return toast.error("اختر الطفل");
    setBusy(true);
    const { data: auth } = await supabase.auth.getUser();
    const today = new Date().toISOString().slice(0, 10);
    const { data, error } = await supabase
      .from("evaluations")
      .insert({
        student_id: qStudent,
        level: qLevel,
        month: qMonth,
        year: qYear,
        eval_date: today,
        ratings: {},
        created_by: auth.user?.id,
      })
      .select()
      .single();
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("تم الإنشاء");
    setOpen(false);
    navigate({ to: "/admin/evaluations/$id", params: { id: data.id } });
  };

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">التقييمات الشهرية</h1>
        <div className="flex gap-2">
          <button
            onClick={() => setOpen(true)}
            className="inline-flex items-center gap-2 rounded-lg border bg-card px-4 py-2 font-medium hover:bg-accent"
          >
            <Zap className="h-4 w-4" />
            إنشاء سريع
          </button>
          <Link
            to="/admin/evaluations/new"
            className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 font-medium text-primary-foreground"
          >
            <Plus className="h-4 w-4" />
            تقييم جديد
          </Link>
        </div>
      </div>

      <div className="mb-4 flex flex-wrap gap-3">
        <select
          value={month}
          onChange={(e) => setMonth(e.target.value === "" ? "" : Number(e.target.value))}
          className="input max-w-xs"
        >
          <option value="">كل الأشهر</option>
          {MONTH_NAMES.map((m, i) => (
            <option key={i} value={i + 1}>
              {m}
            </option>
          ))}
        </select>
        <input
          type="number"
          value={year}
          onChange={(e) => setYear(Number(e.target.value))}
          className="input max-w-[140px]"
        />
      </div>

      <div className="overflow-x-auto rounded-2xl border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-right">
            <tr>
              <th className="p-3">الطفل</th>
              <th className="p-3">الأستاذ</th>
              <th className="p-3">المستوى</th>
              <th className="p-3">الشهر</th>
              <th className="p-3">التاريخ</th>
              <th className="p-3">المربية</th>
              <th className="p-3"></th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-6 text-center text-muted-foreground">
                  لا توجد تقييمات
                </td>
              </tr>
            ) : (
              rows.map((r) => (
                <tr key={r.id} className="border-t">
                  <td className="p-3 font-medium">{r.students?.full_name || "—"}</td>
                  <td className="p-3 text-muted-foreground">
                    {(r.students?.teacher_id && teachers[r.students.teacher_id]) || "—"}
                  </td>
                  <td className="p-3">المستوى {r.level}</td>
                  <td className="p-3">
                    {MONTH_NAMES[r.month - 1]} {r.year}
                  </td>
                  <td className="p-3" dir="ltr">
                    {r.eval_date}
                  </td>
                  <td className="p-3">{r.educator_name || "—"}</td>
                  <td className="p-3">
                    <div className="flex justify-end gap-2">
                      <Link
                        to="/admin/evaluations/$id"
                        params={{ id: r.id }}
                        className="rounded p-2 hover:bg-accent"
                      >
                        <Eye className="h-4 w-4" />
                      </Link>
                      {isAdmin && (
                        <button
                          onClick={() => remove(r.id)}
                          className="rounded p-2 text-destructive hover:bg-destructive/10"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>إنشاء تقييم سريع</DialogTitle>
          </DialogHeader>
          <form onSubmit={quickCreate} className="space-y-4">
            <div>
              <label className="mb-1 block text-sm font-medium">الطفل</label>
              <select
                required
                value={qStudent}
                onChange={(e) => setQStudent(e.target.value)}
                className="input"
              >
                <option value="">— اختر —</option>
                {students.map((s) => {
                  const t = s.teacher_id ? teachers[s.teacher_id] : "";
                  return (
                    <option key={s.id} value={s.id}>
                      {s.full_name}
                      {t ? ` — أستاذ: ${t}` : ""}
                    </option>
                  );
                })}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1 block text-sm font-medium">الشهر</label>
                <select
                  value={qMonth}
                  onChange={(e) => setQMonth(Number(e.target.value))}
                  className="input"
                >
                  {MONTH_NAMES.map((m, i) => (
                    <option key={i} value={i + 1}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium">السنة</label>
                <input
                  type="number"
                  value={qYear}
                  onChange={(e) => setQYear(Number(e.target.value))}
                  className="input"
                />
              </div>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium">المستوى</label>
              <select
                value={qLevel}
                onChange={(e) => setQLevel(Number(e.target.value))}
                className="input"
              >
                <option value={1}>المستوى 1</option>
                <option value={2}>المستوى 2</option>
              </select>
            </div>
            <DialogFooter>
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="rounded-lg border px-4 py-2"
              >
                إلغاء
              </button>
              <button
                disabled={busy}
                className="rounded-lg bg-primary px-4 py-2 font-medium text-primary-foreground disabled:opacity-50"
              >
                {busy ? "..." : "إنشاء ومتابعة"}
              </button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
