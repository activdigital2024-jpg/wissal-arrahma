import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  getTemplate,
  RATING_OPTIONS,
  MONTH_NAMES,
  type RatingValue,
} from "@/lib/evaluationTemplates";
import { EvaluationForm } from "@/components/EvaluationForm";
import { Printer, Pencil, MessageCircle } from "lucide-react";
import logo from "@/assets/logo.jpg";

export const Route = createFileRoute("/admin/evaluations/$id")({
  component: EvaluationDetail,
});

type EvalRow = {
  id: string;
  student_id: string;
  level: number;
  month: number;
  year: number;
  eval_date: string;
  child_age: string | null;
  educator_name: string | null;
  ratings: Record<string, RatingValue>;
  general_notes: string | null;
  recommendations: string | null;
  students?: { full_name: string; guardian_phone: string | null; guardian_name: string | null } | null;
};

function EvaluationDetail() {
  const { id } = Route.useParams();
  const [data, setData] = useState<EvalRow | null>(null);
  const [editing, setEditing] = useState(false);
  const [orgName, setOrgName] = useState("جمعية وصال الرحمة");

  useEffect(() => {
    supabase
      .from("evaluations")
      .select("*, students(full_name, guardian_phone, guardian_name)")
      .eq("id", id)
      .single()
      .then(({ data }) => setData(data as unknown as EvalRow));
    supabase
      .from("app_settings")
      .select("org_name")
      .eq("id", 1)
      .single()
      .then(({ data }) => data?.org_name && setOrgName(data.org_name));
  }, [id]);

  if (!data) return <div>جارٍ التحميل...</div>;

  if (editing) {
    return (
      <div>
        <button
          onClick={() => setEditing(false)}
          className="mb-4 text-sm text-muted-foreground hover:underline"
        >
          ← إلغاء
        </button>
        <EvaluationForm
          evaluationId={data.id}
          initial={{
            student_id: data.student_id,
            level: data.level,
            month: data.month,
            year: data.year,
            eval_date: data.eval_date,
            child_age: data.child_age || "",
            educator_name: data.educator_name || "",
            ratings: data.ratings || {},
            general_notes: data.general_notes || "",
            recommendations: data.recommendations || "",
          }}
        />
      </div>
    );
  }

  const template = getTemplate(data.level);
  const labelOf = (v: RatingValue) =>
    RATING_OPTIONS.find((o) => o.value === v)?.label || "";

  const sendWhatsApp = () => {
    const phone = (data.students?.guardian_phone || "").replace(/[^\d]/g, "");
    if (!phone) {
      alert("لا يوجد رقم هاتف لولي الأمر. أضفه في صفحة الطلاب.");
      return;
    }
    const wa = phone.startsWith("212") ? phone : phone.startsWith("0") ? "212" + phone.slice(1) : phone;
    const lines: string[] = [];
    lines.push(`*${orgName}*`);
    lines.push(`📋 تقييم شهري — ${MONTH_NAMES[data.month - 1]} ${data.year}`);
    lines.push("");
    lines.push(`👶 الطفل(ة): ${data.students?.full_name || "—"}`);
    if (data.educator_name) lines.push(`👩‍🏫 المربية: ${data.educator_name}`);
    lines.push("");
    template.forEach((section) => {
      lines.push(`*${section.title}*`);
      section.items.forEach((item) => {
        const v = data.ratings?.[item];
        if (v) lines.push(`• ${item}: ${labelOf(v)}`);
      });
      lines.push("");
    });
    if (data.general_notes) {
      lines.push("*ملاحظات عامة:*");
      lines.push(data.general_notes);
      lines.push("");
    }
    if (data.recommendations) {
      lines.push("*توصيات شهرية:*");
      lines.push(data.recommendations);
    }
    const text = encodeURIComponent(lines.join("\n"));
    window.open(`https://wa.me/${wa}?text=${text}`, "_blank");
  };

  return (
    <div>
      <div className="mb-4 flex flex-wrap justify-between gap-2 print:hidden">
        <Link to="/admin/evaluations" className="text-sm text-muted-foreground hover:underline">
          ← العودة
        </Link>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={sendWhatsApp}
            className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700"
          >
            <MessageCircle className="h-4 w-4" /> إرسال للوالدين عبر واتساب
          </button>
          <button
            onClick={() => setEditing(true)}
            className="inline-flex items-center gap-2 rounded-lg border px-4 py-2 text-sm hover:bg-accent"
          >
            <Pencil className="h-4 w-4" /> تعديل
          </button>
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
          >
            <Printer className="h-4 w-4" /> طباعة
          </button>
        </div>
      </div>

      <div className="mx-auto max-w-4xl rounded-2xl border bg-card p-8 print:border-0 print:shadow-none">
        <div className="mb-6 flex items-center justify-between border-b pb-4">
          <img src={logo} alt={orgName} className="h-16 w-16 rounded-full object-cover" />
          <div className="text-center">
            <h1 className="text-2xl font-bold">{orgName}</h1>
            <p className="mt-1 text-lg text-primary">تقييم شهري</p>
          </div>
          <div className="w-16" />
        </div>

        <div className="mb-6 grid gap-3 rounded-lg bg-muted/30 p-4 sm:grid-cols-2">
          <Field label="اسم الطفل(ة)" value={data.students?.full_name || "—"} />
          <Field label="السن" value={data.child_age || "—"} />
          <Field label="اسم المربية" value={data.educator_name || "—"} />
          <Field label="التاريخ" value={`${MONTH_NAMES[data.month - 1]} ${data.year}`} />
        </div>

        {template.map((section) => (
          <div key={section.title} className="mb-5">
            <h3 className="mb-2 rounded bg-primary/10 px-3 py-2 font-bold text-primary">
              {section.title}
            </h3>
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="bg-muted/40">
                  <th className="border p-2 text-right">العنصر</th>
                  {RATING_OPTIONS.map((o) => (
                    <th key={o.value} className="border p-2 text-center font-medium">
                      {o.label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {section.items.map((item) => (
                  <tr key={item}>
                    <td className="border p-2">{item}</td>
                    {RATING_OPTIONS.map((o) => (
                      <td key={o.value} className="border p-2 text-center">
                        {data.ratings?.[item] === o.value ? "✓" : ""}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))}

        {data.general_notes && (
          <div className="mb-4 rounded-lg border p-4">
            <h4 className="mb-2 font-bold">ملاحظات عامة حول أداء الطفل</h4>
            <p className="whitespace-pre-wrap text-sm">{data.general_notes}</p>
          </div>
        )}
        {data.recommendations && (
          <div className="rounded-lg border p-4">
            <h4 className="mb-2 font-bold">توصيات شهرية</h4>
            <p className="whitespace-pre-wrap text-sm">{data.recommendations}</p>
          </div>
        )}

        <div className="mt-10 flex justify-between text-sm text-muted-foreground">
          <div>
            <p>توقيع المربية</p>
            <p className="mt-8 border-t pt-1">..............................</p>
          </div>
          <div>
            <p>توقيع المسؤول</p>
            <p className="mt-8 border-t pt-1">..............................</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex gap-2">
      <span className="font-bold">{label}:</span>
      <span>{value}</span>
    </div>
  );
}
